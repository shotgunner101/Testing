General sample pack
__________________________________________________________________
 
VBScript samples from JSWare - www.jsware.net
__________________________________________________________________

   These scripts are primarily intended as examples for people interested in
scripting. They've been tested for functionality. Nevertheless, you can't
assume that they''ll always 'just work'. Your configuration may be different. 
You use them at your own risk. Feel free to change them or distribute them.  

 Many of the sampler scripts were written circa 2000. The latest package
has been updated as of Dec., 2011. Many of the older scripts were only
relevant on Windows 98/ME. The latest batch have been written on XP.
 
  If you open these scripts in Notepad you'll see comments at the top
that explain their purpose.

  Many of these scripts use an InputBox to get information. A much
easier method in many cases is drag/drop, however, drag/drop in Vista/7
can be a problem due to extreme restrictions. See "Vista-7 drop option.vbs"
for options.

 _________________________________________________________

__________________________________________________________

License:

You use all script code and components from JSWare at your own risk.

  The components (compiled DLL and EXE files) may be used for personal or
commercial purposes. No payment or attribution is required for either use.
The components may be redistributed if they are required as support files 
for scripts or software that you have written.
   Also, the script code may be used freely, in part or as whole scripts,
for any purpose, personal or commercial, without payment or attribution.

  I ask only that you not redistribute these scripts and components, except
as required for your direct use. Instead, please direct others to obtain copies
of JSWare scripts and components directly from www.jsware.net.

  Also, none of the code here may be redistributed under another license. If a 
work using code from JSWare is distributed with restrictions of any kind 
the code from JSWare must be kept exempt from those restrictions. 
This includes, but is not limited to, code sold for profit, code with usage restrictions
and code distributed as so-called "Open Source" with redistribution restrictions. 

                                         Joe Priestley


JSWare
www.jsware.net
jsware@jsware.net  



Please note: JSWare does not accept "webmail"
from hotmail, yahoo, facebook, or gmail.
For further explanation see:
www.jsware.net/jsware/contact.php5
